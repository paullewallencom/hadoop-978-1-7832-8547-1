package chapter9;

/*
* @author Srinath Perera (hemapani@apache.org)
*/
public interface ClusterablePoint {
      public double getDistance(ClusterablePoint other);
      public String print();
}
